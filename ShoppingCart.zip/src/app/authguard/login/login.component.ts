import { Component, OnInit } from '@angular/core';
import { AuthService } from '../auth.service';
import { Router, NavigationExtras } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  ngOnInit(): void {
  }
  message: string;
  messagevalidornot: string;
  UserName: string;
  Password: string;
  getusername : string = 'admin@gmail.com';
  getpassword : string = 'admin123';
  
  constructor(public authService: AuthService, public router: Router) {
    this.setMessage();
  }

  setMessage() {
    this.message = 'Logged ' + (this.authService.isLoggedIn ? 'in' : 'out');
    console.log(this.message);
  }

  login(username: string, password: string) {
    this.messagevalidornot = 'Trying to log in ...';
    if (username == 'admin@gmail.com' && password == 'admin123') {
      this.authService.login().subscribe(() => {
        this.setMessage();
        if (this.authService.isLoggedIn) {
          const redirectUrl = '/productlist';

          let navigationExtras: NavigationExtras = {
            queryParamsHandling: 'preserve',
            preserveFragment: true
          };

          this.router.navigate([redirectUrl], navigationExtras);
        }
      });
    }
    else{
      this.messagevalidornot = 'Wrong UserName Or Paasword! Try Again!';
    }
  }
}
