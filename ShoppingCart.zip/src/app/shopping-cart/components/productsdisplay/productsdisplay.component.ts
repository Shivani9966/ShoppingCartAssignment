import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { Products } from './products';

@Component({
  selector: 'app-productsdisplay',
  templateUrl: './productsdisplay.component.html',
  styleUrls: ['./productsdisplay.component.css']
})
export class ProductsdisplayComponent implements OnInit {
  constructor() { }

  ngOnInit(): void {
  }
  productItem: Products[] = [
    new Products(1, 'Timex', '../../../assets/images/1.jpg', 2000, 'Timex Standard watch is a classic simple watch designed for any occasion.'),
    new Products(2, 'MiBand4', '../../../assets/images/2.jpg', 2500, 'Mi Smart Band 4 will track your heart rate, calories burned and more...'),
    new Products(3, 'Casio', '../../../assets/images/3.jpg', 3000, 'Casio is most commonly known for making durable and reliable electronic products.'),
    new Products(4, 'Rolex', '../../../assets/images/4.jpg', 4000, 'Wearing a Rolex watch enables entry into a world of unlimited possibilities.'),
    new Products(5, 'Omega', '../../../assets/images/5.jpg', 2000, 'Omega SA is a Swiss luxury watchmaker based in Biel/Bienne, Switzerland.'),
    new Products(6, 'MiBand3', '../../../assets/images/6.jpeg', 1800, 'The all-new Mi Band 3 has an OLED touch display allowing you to read messages and notification without taking your phone.'),
    new Products(7, 'Fastrack', '../../../assets/images/7.jpg', 3000, 'Fastrack was spun off as an independent brand targeting the urban youth and growing fashion industry in India.'),
    new Products(8, 'Swatch', '../../../assets/images/8.jpg', 2500, 'Swatch watches are affordable Swiss-made watches.'),
    new Products(9, 'Fossil', '../../../assets/images/9.jpg', 2300, 'Fossil also makes licensed accessories for brands such as Puma, Emporio Armani, Michael Kors, DKNY, Diesel, Kate Spade New York, Tory Burch, Chaps, and Armani Exchange.')
  ]
  @Output() cartUpdated = new EventEmitter<{
    productId: number,
    productName: string,
    productPrice: number
  }>();

  onCartUpdated(event) {
    const id = event.target.getAttribute('id');
    const index = this.productItem.findIndex(elem => elem.id == id);
    console.log(id);
    this.cartUpdated.emit({
      productId: this.productItem[index].id,
      productName: this.productItem[index].ItemName,
      productPrice: this.productItem[index].ItemPrice
    });
    console.log(this.cartUpdated);
  }
}