export class Products {
    public id: number;
    public ItemName: string;
    public ItemImage: string;
    public ItemPrice: number;
    public ItemDescription: string;

    constructor(id: number, ItemName: string, ItemImage: string, ItemPrice: number, ItemDescription: string) {
        this.id = id;
        this.ItemName = ItemName;
        this.ItemDescription = ItemDescription;
        this.ItemImage = ItemImage;
        this.ItemPrice = ItemPrice;
    }

}
