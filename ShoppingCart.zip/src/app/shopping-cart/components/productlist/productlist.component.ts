import { Component, OnInit } from '@angular/core';
import { AuthService } from 'src/app/authguard/auth.service';
import { Router } from '@angular/router';
import { Cart } from '../cart/cart';

@Component({
  selector: 'app-productlist',
  templateUrl: './productlist.component.html',
  styleUrls: ['./productlist.component.css']
})
export class ProductlistComponent implements OnInit {

  constructor(public authService: AuthService, public router: Router) {
    this.setMessage();
  }
  message: string;
  setMessage() {
    this.message = 'Logged ' + (this.authService.isLoggedIn ? 'in' : 'out');
  }
  cartTotal: number = 0;
  cartItems: Cart[] = [];

  ngOnInit() {
    this.updateCartTotal();    
  }

  onCartItemDeleted(productData:{productId: number}) {
    const index = this.cartItems.findIndex( elem => elem.id == productData.productId )
    this.cartItems.splice(index,1);
    this.updateCartTotal();
  }

  onCartItemChanged(productData:{productId: number}) {
    this.updateCartTotal();
  }

  onCartUpdated(productData: {
                productId: number,
                productName: string,
                productPrice: number} ) {
    const index = this.cartItems.findIndex( elem => elem.id == productData.productId )
    if (index===-1) {
      this.cartItems.push({
          id: productData.productId,
          name: productData.productName,
          quantity: 1,
          price: productData.productPrice,
          total: productData.productPrice * 1
      });
    } else {
      this.cartItems[index].id = productData.productId;
      this.cartItems[index].name = productData.productName;
      this.cartItems[index].quantity++;
      this.cartItems[index].price = productData.productPrice;
      this.cartItems[index].total = this.cartItems[index].price * this.cartItems[index].quantity;
    }
      this.updateCartTotal();
  }

  updateCartTotal() {
    //the code to update the total property of the cart
    let total = 0;
    this.cartItems.map( elem => total = total + elem.quantity*elem.price);
    this.cartTotal = total;
 }   

  logout() {
    this.authService.logout();
    this.setMessage();
  }
}
