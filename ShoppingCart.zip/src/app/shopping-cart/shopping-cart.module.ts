import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductlistComponent } from './components/productlist/productlist.component';

import { ShoppingRoutingModule } from './shopping-cart-routing.module';
import { ProductsdisplayComponent } from './components/productsdisplay/productsdisplay.component';
import { CartComponent } from './components/cart/cart.component';
import { CartitemComponent } from './components/cart/cartitem/cartitem.component'
import { FormsModule } from '@angular/forms';
@NgModule({
  declarations: [ProductlistComponent, ProductsdisplayComponent, CartComponent, CartitemComponent],
  imports: [
    CommonModule,
    ShoppingRoutingModule,
    FormsModule
  ]
})
export class ShoppingCartModule { }
