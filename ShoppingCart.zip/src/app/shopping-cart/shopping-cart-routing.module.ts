import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { ProductlistComponent }  from './components/productlist/productlist.component';

import { AuthguardGuard }                from '../authguard/authguard.guard';

const adminRoutes: Routes = [
  {
    path: '',
    component: ProductlistComponent,
    canActivate: [AuthguardGuard],
    children: [
      {
        path: '',
        canActivateChild: [AuthguardGuard],
        children: [
          { path: '', component: ProductlistComponent }
        ]
      }
    ]
  }
];

@NgModule({
  imports: [
    RouterModule.forChild(adminRoutes)
  ],
  exports: [
    RouterModule
  ]
})
export class ShoppingRoutingModule {}
