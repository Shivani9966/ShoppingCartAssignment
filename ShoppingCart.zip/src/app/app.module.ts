import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HomeModule } from './home/home.module';
import { ShoppingCartModule } from './shopping-cart/shopping-cart.module';
import { FormsModule } from '@angular/forms';
import { allinoneroutingmodule } from './all-in-one/all-in-one-routing.module';
import { AllInOneModule } from './all-in-one/all-in-one.module';
import { HttpClientModule } from '@angular/common/http';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HomeModule,
    ShoppingCartModule,
    FormsModule,
    allinoneroutingmodule,
    AllInOneModule,
    HttpClientModule,
    NgbModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
