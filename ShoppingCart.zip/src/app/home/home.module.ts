import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HeaderComponent } from './components/header/header.component';
import { FooterComponent } from './components/footer/footer.component';
import { LoginComponent } from '../authguard/login/login.component';
import { RegisterComponent } from './components/register/register.component';
import { ForgotpasswordComponent } from './components/forgotpassword/forgotpassword.component';
import { PageNotFoundComponent } from './components/page-not-found/page-not-found.component';
import { HomeComponent } from './components/home/home.component';
import { AppRoutingModule } from './home-routing.module';
import { FormsModule } from '@angular/forms';
import { PasswordmatchDirective } from './components/register/passwordmatch.directive';


@NgModule({
  declarations: [HeaderComponent, FooterComponent, LoginComponent, RegisterComponent, ForgotpasswordComponent, PageNotFoundComponent, HomeComponent, PasswordmatchDirective],
  imports: [
    CommonModule,
    AppRoutingModule,
    FormsModule
  ]
})
export class HomeModule { }
