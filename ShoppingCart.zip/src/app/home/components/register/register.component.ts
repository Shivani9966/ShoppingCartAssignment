import { Component, OnInit } from '@angular/core';
import { Register } from './register';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  constructor() { }
  ngOnInit(): void {
  }
  mobilenumberpattern = "^((\\+91-?)|0)?[0-9]{10}$";
  registerdata : Register ={
    Username: null,
    Email: null,
    Address: null,
    ContactNumber: null,
    Password: null,
    ConfirmPassword: null
  }
}
