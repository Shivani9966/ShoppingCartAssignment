export class Register {
    Username: string;
    Email: string;
    ContactNumber: string;
    Address: string;
    Password: string;
    ConfirmPassword: string;
}
