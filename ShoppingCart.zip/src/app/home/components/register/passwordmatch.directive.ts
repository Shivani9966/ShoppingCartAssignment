import { Directive, Input } from '@angular/core';
import { AbstractControl, NG_VALIDATORS, Validator } from '@angular/forms';

@Directive({
  selector: '[appPasswordmatch]',
  providers: [{
    provide: NG_VALIDATORS,
    useExisting: PasswordmatchDirective,
    multi: true
}]

})
export class PasswordmatchDirective implements Validator{

  constructor() { }
  @Input() appPasswordmatch: string;
  validate(control: AbstractControl): { [key: string]: any } | null {
      const controlToCompare = control.parent.get(this.appPasswordmatch);
      if (controlToCompare && controlToCompare.value !== control.value) {
          return { 'notEqual': true };
      }

      return null;
  }
}
