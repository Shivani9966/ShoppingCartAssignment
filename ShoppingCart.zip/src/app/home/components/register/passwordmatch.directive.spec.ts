import { PasswordmatchDirective } from './passwordmatch.directive';

describe('PasswordmatchDirective', () => {
  it('should create an instance', () => {
    const directive = new PasswordmatchDirective();
    expect(directive).toBeTruthy();
  });
});
