import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PageNotFoundComponent } from './home/components/page-not-found/page-not-found.component';
import { HomeComponent } from './home/components/home/home.component';
import { LoginComponent } from './authguard/login/login.component';
import { RegisterComponent } from './home/components/register/register.component';
import { ForgotpasswordComponent } from './home/components/forgotpassword/forgotpassword.component';
import { AuthguardGuard } from './authguard/authguard.guard';
import { AllInOneComponent } from './all-in-one/all-in-one.component';
import { PipeComponent } from './all-in-one/pipe/pipe.component';
import { DirectiveComponent } from './all-in-one/directive/directive.component';
import { DemoComponent } from './all-in-one/demo/demo.component';
import { ApiServiceDemoComponent } from './all-in-one/api-service-demo/api-service-demo.component';
import { PostApiServiceComponent } from './all-in-one/api-service-demo/post-api-service/post-api-service.component';
import { GetApiServiceComponent } from './all-in-one/api-service-demo/get-api-service/get-api-service.component';
import { PutApiServiceComponent } from './all-in-one/api-service-demo/put-api-service/put-api-service.component';
import { DetailApiServiceComponent } from './all-in-one/api-service-demo/detail-api-service/detail-api-service.component';
import { DeleteApiServiceComponent } from './all-in-one/api-service-demo/delete-api-service/delete-api-service.component';

const routes: Routes = [
  {path: "home", component: HomeComponent},
  {path: "login", component: LoginComponent},
  {path: "register", component: RegisterComponent},
  {path: "forgotpassword", component: ForgotpasswordComponent},
  {path: "AllConcepts", component: AllInOneComponent},
  {path: "services", component: ApiServiceDemoComponent},
  {path: "pipes", component: PipeComponent},
  {path: "directives", component: DirectiveComponent},
  {path: "others", component: DemoComponent},
  {path: "poststudents", component: PostApiServiceComponent},
  {path: "getstudents", component: GetApiServiceComponent},
  {path: "editstudents/:id", component: PutApiServiceComponent},
  {path: "deletestudents/:id", component: DeleteApiServiceComponent},
  {path: "studentdetails/:id", component: DetailApiServiceComponent},
  {path: 'productlist',loadChildren: () => import('./shopping-cart/shopping-cart.module').then(m => m.ShoppingCartModule),canLoad: [AuthguardGuard]},
  { path: '',redirectTo: '/home',pathMatch: 'full'},
  { path: '**', component:  PageNotFoundComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
