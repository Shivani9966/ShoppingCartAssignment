import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { ApiData } from './api-data';
import { Router } from '@angular/router';
import { tap, catchError } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class ApiServiceDemoService {

  // Access Api Data by starting json Server
  //--->npm run json:server
  BaseUrl = 'http://localhost:3000/Students'
  
  httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
  };
  constructor(private httpclient: HttpClient) { }

  getstudents(): Observable<any> {
    return this.httpclient.get(this.BaseUrl)
  }

  poststudent(objpost: ApiData): Observable<any> {
    return this.httpclient.
                post<ApiData>
                    (
                        this.BaseUrl,
                        objpost,
                        this.httpOptions
                    )
  }

  updateStudent(objpost: ApiData): Observable<any> {
    return this.httpclient.put<ApiData>(
                        `${this.BaseUrl}/${objpost.id}`,
                        objpost,
                        this.httpOptions
                        )
  }

  private handleError<T>(operation = 'operation', result?: T) {
    return (error: any): Observable<T> => {
      console.error(error);
      return of(result as T);
    };
  }

  getStudentById(id: number): Observable<ApiData> {
    const url = `${this.BaseUrl}/${id}`;
    return this.httpclient.
                  get<ApiData>(url)
                  .pipe(
                        catchError(this.handleError<ApiData>(`getHero id=${id}`))
                      );
  }

  deleteStudentById(sid: number): Observable<ApiData> {
    const url = `${this.BaseUrl}/${sid}`;
    console.log(sid);
    return this.httpclient.delete<ApiData>
                    (
                      url,
                      this.httpOptions
                    ).pipe(
                          catchError(this.handleError<ApiData>('deleteHero')               )
                          );
  }
  
}
