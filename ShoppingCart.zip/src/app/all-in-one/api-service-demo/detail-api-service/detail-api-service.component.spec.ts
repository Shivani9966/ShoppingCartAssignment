import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DetailApiServiceComponent } from './detail-api-service.component';

describe('DetailApiServiceComponent', () => {
  let component: DetailApiServiceComponent;
  let fixture: ComponentFixture<DetailApiServiceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DetailApiServiceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DetailApiServiceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
