import { Component, OnInit, Input } from '@angular/core';
import { ApiData } from '../api-data';
import { ActivatedRoute } from '@angular/router';
import { ApiServiceDemoService } from '../api-service-demo.service';
import { Location } from '@angular/common';

@Component({
  selector: 'app-detail-api-service',
  templateUrl: './detail-api-service.component.html',
  styleUrls: ['./detail-api-service.component.css']
})
export class DetailApiServiceComponent implements OnInit {

  
  @Input() data: ApiData;
  constructor(
    private route: ActivatedRoute,
    private service: ApiServiceDemoService,
    private location: Location
  ) {}

  ngOnInit(): void {
    this.getStudent();
  }

  getStudent(): void {
    const id = +this.route.snapshot.paramMap.get('id');
    this.service.getStudentById(id)
      .subscribe(data => this.data = data);
  }
  
  goBack(): void {
    this.location.back();
  }

}
