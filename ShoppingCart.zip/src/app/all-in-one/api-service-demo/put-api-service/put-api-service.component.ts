import { Component, OnInit, Input } from '@angular/core';
import { ApiData } from '../api-data';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiServiceDemoService } from '../api-service-demo.service';
import { Location } from '@angular/common';

@Component({
  selector: 'app-put-api-service',
  templateUrl: './put-api-service.component.html',
  styleUrls: ['./put-api-service.component.css']
})
export class PutApiServiceComponent implements OnInit {

  @Input() data: ApiData;
  mobilenumberpattern = "^((\\+91-?)|0)?[0-9]{10}$"; 

  constructor(
    private route: ActivatedRoute,
    private service: ApiServiceDemoService,
    private location: Location,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.getStudent();
  }

  getStudent(): void {
    const id = +this.route.snapshot.paramMap.get('id');
    this.service.getStudentById(id)
      .subscribe(data => this.data = data);
  }

  goBack(): void {
    this.location.back();
  }

  updateStudent(): void
  {
    this.service.updateStudent(this.data)
      .subscribe
      (
        () => this.router.navigate(['/getstudents'])
      );
  }

}
