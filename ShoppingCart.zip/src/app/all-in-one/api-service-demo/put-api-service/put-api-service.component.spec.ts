import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PutApiServiceComponent } from './put-api-service.component';

describe('PutApiServiceComponent', () => {
  let component: PutApiServiceComponent;
  let fixture: ComponentFixture<PutApiServiceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PutApiServiceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PutApiServiceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
