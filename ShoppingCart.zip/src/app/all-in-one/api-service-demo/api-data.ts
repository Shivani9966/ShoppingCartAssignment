export class ApiData {
    id: number;
    FirstName: string;
    LastName: string;
    Email: string;
    ContactNumber: number;
    DateOfBirth: string;

    constructor(
        id:number,
        FirstName: string,
        LastName: string,
        Email: string,
        ContactNumber: number,
        DateOfBirth: string
        )
    {
        id = this.id;
        FirstName = this.FirstName;
        LastName = this.LastName;
        Email = this.Email;
        ContactNumber = this.ContactNumber;
        DateOfBirth = this.DateOfBirth;
    }
}
