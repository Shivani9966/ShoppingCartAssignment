import { TestBed } from '@angular/core/testing';

import { ApiServiceDemoService } from './api-service-demo.service';

describe('ApiServiceDemoService', () => {
  let service: ApiServiceDemoService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(ApiServiceDemoService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
