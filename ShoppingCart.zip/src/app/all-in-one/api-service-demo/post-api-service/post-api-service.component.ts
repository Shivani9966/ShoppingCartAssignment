import { Component, OnInit } from '@angular/core';
import { NgbDateStruct} from '@ng-bootstrap/ng-bootstrap';
import { ApiData } from '../api-data';
import { ApiServiceDemoService } from '../api-service-demo.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-post-api-service',
  templateUrl: './post-api-service.component.html',
  styleUrls: ['./post-api-service.component.css']
})
export class PostApiServiceComponent implements OnInit {
 
  model: NgbDateStruct;
  objapi : ApiData;
  
  ngOnInit(): void {
  }
  constructor(
    private service : ApiServiceDemoService,
    private router: Router
    ) {}

  mobilenumberpattern = "^((\\+91-?)|0)?[0-9]{10}$"; 
  
  postapidata : ApiData ={
    id: null,
    FirstName: null,
    LastName: null,
    Email: null,
    ContactNumber: null,
    DateOfBirth: null
  }

  poststudent()
  {
    this.service.poststudent(this.postapidata)
    .subscribe(
      (data : ApiData)=>
      {
          console.log(data);
          this.objapi = data;
      }
    )
    this.router.navigate(['/services'])
  }
}
