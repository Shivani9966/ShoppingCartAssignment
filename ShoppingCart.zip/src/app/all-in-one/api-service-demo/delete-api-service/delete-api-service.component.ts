import { Component, OnInit, Input } from '@angular/core';
import { ApiData } from '../api-data';
import { ActivatedRoute, Router } from '@angular/router';
import { ApiServiceDemoService } from '../api-service-demo.service';
import { Location } from '@angular/common';

@Component({
  selector: 'app-delete-api-service',
  templateUrl: './delete-api-service.component.html',
  styleUrls: ['./delete-api-service.component.css']
})
export class DeleteApiServiceComponent implements OnInit {

  @Input() data: ApiData;

  students: ApiData[];

  constructor
  (
    private route: ActivatedRoute,
    private service: ApiServiceDemoService,
    private location: Location,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.getStudent();
  }

  getStudent(): void {
    const id = +this.route.snapshot.paramMap.get('id');
    this.service.getStudentById(id)
      .subscribe(data => this.data = data);
  }

  goBack(): void {
    this.location.back();
  }

  deletestudent(student: ApiData): void {
    this.service.deleteStudentById(student.id)
      .subscribe(
        () => this.router.navigate(['/getstudents'])
      );
  }
}
