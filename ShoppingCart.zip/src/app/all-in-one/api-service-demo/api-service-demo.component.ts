import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-api-service-demo',
  templateUrl: './api-service-demo.component.html',
  styleUrls: ['./api-service-demo.component.css']
})
export class ApiServiceDemoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
}
