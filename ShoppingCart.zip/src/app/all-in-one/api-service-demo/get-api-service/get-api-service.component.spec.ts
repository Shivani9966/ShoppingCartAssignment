import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GetApiServiceComponent } from './get-api-service.component';

describe('GetApiServiceComponent', () => {
  let component: GetApiServiceComponent;
  let fixture: ComponentFixture<GetApiServiceComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GetApiServiceComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GetApiServiceComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
