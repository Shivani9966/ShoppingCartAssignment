import { Component, OnInit } from '@angular/core';
import { ApiServiceDemoService } from '../api-service-demo.service';
import { ApiData } from '../api-data';

@Component({
  selector: 'app-get-api-service',
  templateUrl: './get-api-service.component.html',
  styleUrls: ['./get-api-service.component.css']
})
export class GetApiServiceComponent implements OnInit {

  constructor(private service: ApiServiceDemoService) { }
  
  listapidata: ApiData[];
  
  ngOnInit(): void {
    this.getStudents();
  }

  getStudents() {
    this.service.getstudents()
      .subscribe (
        data => {
          this.listapidata = data;
        }
      )
  }
}
