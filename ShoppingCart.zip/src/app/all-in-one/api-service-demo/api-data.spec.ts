import { ApiData } from './api-data';

describe('ApiData', () => {
  it('should create an instance', () => {
    expect(new ApiData()).toBeTruthy();
  });
});
