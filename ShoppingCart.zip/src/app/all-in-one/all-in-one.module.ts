import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DirectiveComponent } from './directive/directive.component';
import { PipeComponent } from './pipe/pipe.component';
import { CustomDirective } from './directive/custom.directive';
import { DirectivedemoDirective } from './directive/directivedemo.directive';
import { HighLightDirective } from './directive/high-light.directive';
import { LightDirective } from './directive/light.directive';
import { AllInOneComponent } from './all-in-one.component';
import { FormsModule } from '@angular/forms';
import { allinoneroutingmodule } from './all-in-one-routing.module';
import { RouterModule } from '@angular/router';
import { CustompipePipe } from './pipe/custompipe.pipe';
import { Custompipe1Pipe } from './pipe/custompipe1.pipe';
import { Custompipe2Pipe } from './pipe/custompipe2.pipe';
import { DemoComponent } from './demo/demo.component';
import { ApiServiceDemoComponent } from './api-service-demo/api-service-demo.component';
import { GetApiServiceComponent } from './api-service-demo/get-api-service/get-api-service.component';
import { PutApiServiceComponent } from './api-service-demo/put-api-service/put-api-service.component';
import { PostApiServiceComponent } from './api-service-demo/post-api-service/post-api-service.component';
import { DeleteApiServiceComponent } from './api-service-demo/delete-api-service/delete-api-service.component';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';
import { DetailApiServiceComponent } from './api-service-demo/detail-api-service/detail-api-service.component';


@NgModule({
  declarations: [DirectiveComponent, PipeComponent, CustomDirective, DirectivedemoDirective, HighLightDirective, LightDirective, AllInOneComponent, CustompipePipe, Custompipe1Pipe, Custompipe2Pipe, DemoComponent, ApiServiceDemoComponent, GetApiServiceComponent, PutApiServiceComponent, PostApiServiceComponent, DeleteApiServiceComponent, DetailApiServiceComponent],
  imports: [
    CommonModule,
    FormsModule,
    allinoneroutingmodule,
    RouterModule,
    NgbModule
  ]
})
export class AllInOneModule {}
