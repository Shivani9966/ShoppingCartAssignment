import { Component, OnInit, Input, EventEmitter, Output } from '@angular/core';

@Component({
  selector: 'app-demo',
  templateUrl: './demo.component.html',
  styleUrls: ['./demo.component.css']
})
export class DemoComponent implements OnInit {

  showifelse1: boolean = true;
  public fun = "";
  constructor() { 
    console.log('log from constructor');
  }
  public val = 'This Message is';
  public data = 'This Message is From';
  public value = 'Hello Component!';
  public publicvalue = 'Hello Component!';
  public url = window.location.href;
  public Message = "";
  @Input('parentData') public parentchilddata;
  @Output() public Event = new EventEmitter();
  ngOnInit(): void {
    console.log('log from ngoninit');
  }
  title = 'Welcome Component !';
  myfunction()
  {
    console.log('Welcome in my function!');
    this.fun = "This is example of Function Calling!";
  }
  div = "";
  btn = "";
  eventbubblediv()
  {
    this.div = "Div is Clicked!";
  }
  eventbubblebutton()
  {
    this.btn = "Button is Clicked!";
  }
  
}
