import { Custompipe2Pipe } from './custompipe2.pipe';

describe('Custompipe2Pipe', () => {
  it('create an instance', () => {
    const pipe = new Custompipe2Pipe();
    expect(pipe).toBeTruthy();
  });
});
