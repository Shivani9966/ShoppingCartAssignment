import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'custompipe1'
})
export class Custompipe1Pipe implements PipeTransform {

  transform(value: number): number {
    return Math.round(value);
  }

}
