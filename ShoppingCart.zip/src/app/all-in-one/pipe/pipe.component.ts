import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pipe',
  templateUrl: './pipe.component.html',
  styleUrls: ['./pipe.component.css']
})
export class PipeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  power = 5;
  factor = 1;
  number = 25.75;
  number1 = 999;
  number2 = 200;
  name = "Pipe demo!";
  person=
  {
    "fname" : "Hello",
    "lname" : "Bye!"
  }
  date = new Date();
}
