import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'custompipe2'
})
export class Custompipe2Pipe implements PipeTransform {

  transform(value1: number, value2: number): number {
    return Math.max(value1,value2);
  }

}
