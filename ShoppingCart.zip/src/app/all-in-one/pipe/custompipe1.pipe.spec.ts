import { Custompipe1Pipe } from './custompipe1.pipe';

describe('Custompipe1Pipe', () => {
  it('create an instance', () => {
    const pipe = new Custompipe1Pipe();
    expect(pipe).toBeTruthy();
  });
});
