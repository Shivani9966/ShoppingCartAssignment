import { Directive, Input, ElementRef, HostListener } from '@angular/core';

@Directive({
  selector: '[appHighLight]'
})
export class HighLightDirective {

  constructor(private e : ElementRef) {
    e.nativeElement.style.backgroundColor = 'green';
  }
  @Input('appHighlight') highlightColor: string;

  @HostListener('mouseenter') onmouseenter()
  {
    this.highlight('red');
  }
  @HostListener('mouseleave') onmouseleave()
  {
    this.highlight(null);
  }
  @HostListener('click') onmouseclick()
  {
    this.highlight('orange');
  }
 
  private highlight(color : string)
  {
    this.e.nativeElement.style.backgroundColor = color;
  }

}
