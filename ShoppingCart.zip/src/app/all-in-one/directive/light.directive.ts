import { Directive, HostListener, Input, ElementRef } from '@angular/core';

@Directive({
  selector: '[appLight]'
})
export class LightDirective {

  constructor(private el: ElementRef) { }

  @Input('appLight') highlightColor: string;

  @HostListener('mouseenter') onMouseEnter() {
    this.highlight(this.highlightColor);
  }

  @HostListener('mouseleave') onMouseLeave() {
    this.highlight(null);
  }

  private highlight(color: string) {
    this.el.nativeElement.style.backgroundColor = color;
  }


}
