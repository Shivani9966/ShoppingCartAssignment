import { LightDirective } from './light.directive';

describe('LightDirective', () => {
  it('should create an instance', () => {
    const directive = new LightDirective();
    expect(directive).toBeTruthy();
  });
});
