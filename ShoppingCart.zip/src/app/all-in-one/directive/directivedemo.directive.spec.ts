import { DirectivedemoDirective } from './directivedemo.directive';

describe('DirectivedemoDirective', () => {
  it('should create an instance', () => {
    const directive = new DirectivedemoDirective();
    expect(directive).toBeTruthy();
  });
});
