import { Directive, Input, HostListener, ElementRef } from '@angular/core';

@Directive({
  selector: '[appCustom]'
})
export class CustomDirective {
  @Input('appCustom') highlightColor: string;

  constructor(private e : ElementRef) { }

  @HostListener('mouseenter') onmouseenter()
  {
    this.highlight('orange');
  }
  @HostListener('click') onmouseclick()
  {
    this.highlight('green');
  }
  @HostListener('mouseleave') onmouseleave()
  {
    this.highlight(null);
  }
  private highlight(color : string)
  {
    this.e.nativeElement.style.backgroundColor = color;
  }
}
