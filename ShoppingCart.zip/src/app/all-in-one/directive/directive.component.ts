import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';
import { FormsModule } from '@angular/forms'

@Component({
  selector: 'app-directive',
  templateUrl: './directive.component.html',
  styleUrls: ['./directive.component.css']
})
export class DirectiveComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    console.log('FromNgOnInt()');
  }

  @Input() displayvalue: boolean = true;
  text: string = 'Directive Demo Example';
  title: string = "List Of Data";
  show: boolean = true;
  show1: boolean = true;
  showifelse: boolean = false;
  userText: string = 'abc';
  color: string;
  highlightColor: string;
  testlist: Test[] = [
    { name: 'abc', description: 'abc Hello World!' },
    { name: "pqr", description: "pqr Hello World!" },
    { name: "xyz", description: "xyz Hello World!" },
  ]
  items: Item[] = [
    { name: 'Mango', val: 1 },
    { name: 'Orange', val: 2 },
    { name: 'Banana', val: 3 },
    { name: 'Apple', val: 4 },
    { name: 'abc', val: 5 }
  ]
  selected: string = 'Mango';
  getColor(country: any) {
    switch (country) {
      case 'India':
        return '#5c00e6';
      case 'USA':
        return '#00cc00';
      case 'Canada':
        return '#660066';
    }
  }

  people: Any[] = [
    {
      "name": "ABC",
      "country": 'India'
    },
    {
      "name": "XYZ",
      "country": 'USA'
    },
    {
      "name": "PQR",
      "country": 'Canada'
    },
    {
      "name": "MNL",
      "country": 'India'
    },
    {
      "name": "QWERT",
      "country": 'USA'
    }
  ];
  odds: odd[] = [
    { value: 1 },
    { value: 3 },
    { value: 5 },
    { value: 7 },
    { value: 9 }
  ];
  evens: even[] = [
    { value: 2 },
    { value: 4 },
    { value: 6 },
    { value: 8 },
    { value: 10 }
  ];
}
class Test {
  name: string;
  description: string;
}
class Item {
  name: string;
  val: number;
}
class Any {
  name: string;
  country: string;
}
class odd {
  value: number;
}
class even {
  value: number;
}
