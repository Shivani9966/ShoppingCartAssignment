import { CustomDirective } from './custom.directive';

describe('CustomDirective', () => {
  it('should create an instance', () => {
    const directive = new CustomDirective();
    expect(directive).toBeTruthy();
  });
});
