1.   ShoppingCart_Angular(Folder)  And ShoppingCart.zip(zip file)  
		Both Are same(one is in folder and other is zip format )

2.   Run Command    -->npm install

3.   There is data.json file for api_service_demo data for CRUD Operation for Students Data
		[(All Concepts-->Services)-->Get Student List / Add / Update/ Delete Student]  To Access that Data using json server

      Run Command    -->npm run json:server

4.    To Access Shopping Cart Login with below credentials:
	   username  :-admin@gmail.com
	   password     :-admin123

Link to GitRepository  :-